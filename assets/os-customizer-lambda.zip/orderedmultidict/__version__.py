# -*- coding: utf-8 -*-

#
# omdict - Ordered Multivalue Dictionary.
#
# Ansgar Grunseid
# grunseid.com
# grunseid@gmail.com
#
# License: Build Amazing Things (Unlicense)
#

__title__ = 'orderedmultidict'
__version__ = '1.0.1'
__license__ = 'Unlicense'
__author__ = 'Ansgar Grunseid'
__contact__ = 'grunseid@gmail.com'
__description__ = 'Ordered Multivalue Dictionary'
__url__ = 'https://github.com/gruns/orderedmultidict'
